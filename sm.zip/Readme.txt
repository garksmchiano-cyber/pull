#by Ankit
Enable/Disable coin system in settings.py
Enable/Disable commands for top 5 players in settings.py
Enable/Disable effects for top 5 players in settings.py

commands list

for vip
	/nv
	/ooh
	/playSound
	/box
	/spaz
	/inv
	/bunny
	/tex
	/list

for admin
	all commands of vip
	/quit
	/kick
	/admin
		usage: /admin <client_id> add/remove [permanent]
		permanent option is optional
	/vip
		usage: similar to /admin
	/freeze
	/sleep
	/thaw
	/kill
	/remove
	/end
	/hug
	/tint
	/sm
	/cameraMode
	/lm
	/gp
	/fly
	/icy
	/floorReflection
	/ac
	/iceOff
	/maxPlayers
	/heal
	/gm
	/reflections
	/shatter
	/cm

for Owner
	all commands of admin
	/id
		to view the unique id of players
		usage: /id <client_id>
		example: /id 113
	/ban
		to ban a player permanently from server
		usage: /ban <client_id>
		example: /ban 113
	/custom
		to give a tag to players
		usage: /custom <client_id> add [tag_to_be_given]
		example: /custom 113 add TaG
			 /custom 113 add \cCrown\c
	/partyname
		to change the name of the server temporarily
		usage: /partyname this_is_new_server_name
		underscore will be replaced by a space
	/public
		to make server private or public temporarily
		usage: public 0 or 1
		0 = private, 1 = public
	/remove


